A Glock 19 Closed Magwell frame that uses front and rear stamped rails from printyour2a.com

Requirements
G26 locking block G19 Slide Assembly kit Glock Lower parts Kit and Magazine.

Print Settings

Slide / railside down
Nozzle: .4mm
Print Temp:225ºC
Bed Temp:55ºC
Adhesion method: Brim
Speed:52mm/s
Layer height:0.16mm
Shell:1.2mm
15% infill overlap
Infill Pattern: Gyroid
Line Supports:10% (your choice of tree supports are fine)

Suggest printing in PLA, PLA+ or ABS. PLA+ works best. Rear supports can be blocked out if desired. These are only recommended settings, adjust as needed. Frame should be printed rails down without raft on a clean bed. Glass is the preferred medium to print on. Do not use frames that are warped or printed poorly.

Slide lock spring insert is if you're having issues with your slide locking in place when in battery.

if the rails are too tight fit put scale to 105%